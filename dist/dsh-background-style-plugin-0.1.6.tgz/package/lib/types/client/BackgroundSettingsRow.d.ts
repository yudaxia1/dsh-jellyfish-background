import type { PropsLocale, PropsRuntime, PropsStore } from '@deepseek-ai/dsh-client-ui-slots';
import type { createBackgroundSettingsStore } from './settings-store.ts';
/** Settings writes supplied by the plugin body. */
export interface BackgroundSettingsInjected {
    setEnabled(enabled: boolean): void;
    setIntensity(intensity: number): void;
    setCount(count: number): void;
}
type Props = PropsRuntime<'settings.general.item'> & PropsStore<ReturnType<typeof createBackgroundSettingsStore>> & PropsLocale<'background.abyss'> & BackgroundSettingsInjected;
/** Display the plugin toggle and animation strength in General settings. */
export declare function BackgroundSettingsRow({ t, useStore, setEnabled, setIntensity, setCount }: Props): import("react").JSX.Element;
export {};
//# sourceMappingURL=BackgroundSettingsRow.d.ts.map