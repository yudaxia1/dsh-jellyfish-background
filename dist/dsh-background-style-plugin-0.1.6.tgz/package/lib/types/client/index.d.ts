/** Full-window animated background and feature-owned General settings row. */
import type { Context as ClientContext } from '@deepseek-ai/cordis';
import { type BackgroundKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Text for the deep-sea background settings row. */
        'background.abyss': BackgroundKey;
    }
}
/** Required DSH client services; their package edges are in dsh.client.inject. */
export declare const inject: string[];
/** Install the theme, scene and settings control for this client fiber. */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map