/** Chinese copy for the feature-owned General settings row. */
export declare const zh: {
    title: string;
    description: string;
    enable: string;
    intensity: string;
    count: string;
    countHint: string;
};
export type BackgroundKey = keyof typeof zh;
/** English copy with the same keys. */
export declare const en: {
    title: string;
    description: string;
    enable: string;
    intensity: string;
    count: string;
    countHint: string;
};
//# sourceMappingURL=locales.d.ts.map