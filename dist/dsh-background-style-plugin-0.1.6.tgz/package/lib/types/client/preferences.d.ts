export declare const DEFAULT_INTENSITY = 65;
export declare const DEFAULT_COUNT = 6;
export declare const MAX_COUNT = 12;
export interface BackgroundPreferences {
    enabled: boolean;
    intensity: number;
    count: number;
}
export declare function normalizeIntensity(value: unknown): number;
export declare function normalizeCount(value: unknown): number;
/** Missing count in older saved settings keeps the original six jellyfish. */
export declare function parsePreferences(raw: string | null): BackgroundPreferences;
//# sourceMappingURL=preferences.d.ts.map