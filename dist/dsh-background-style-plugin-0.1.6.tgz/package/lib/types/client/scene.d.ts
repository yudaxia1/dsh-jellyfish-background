/** Owns one fixed canvas, its animation frame, and all environment listeners. */
export declare class AbyssScene {
    private readonly canvas;
    private readonly context;
    private readonly background;
    private readonly backgroundContext;
    private readonly motion;
    private frame;
    private lastTick;
    private lastPaint;
    private seconds;
    private swimSeconds;
    private width;
    private height;
    private intensity;
    private count;
    private readingShade;
    private readonly onResize;
    private readonly onVisibility;
    private readonly onMotion;
    private readonly tick;
    /** Mount the background canvas and start only when motion is allowed. */
    constructor(intensity: number, count?: number);
    /** Change motion and glow strength without rebuilding the canvas. */
    setIntensity(intensity: number): void;
    /** Update the population immediately while keeping existing paths and phases. */
    setCount(count: number): void;
    /** Remove every resource owned by this plugin instance. */
    dispose(): void;
    private resize;
    private resume;
    /** Cache static colors and grid at CSS resolution to limit extra canvas memory. */
    private cacheBackground;
    private paint;
    private drawStars;
    private drawJellyfish;
}
//# sourceMappingURL=scene.d.ts.map