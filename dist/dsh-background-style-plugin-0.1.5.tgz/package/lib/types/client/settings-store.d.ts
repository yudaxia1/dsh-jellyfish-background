import { type EngineStoreHandle } from '@deepseek-ai/dsh-client-store';
/** State mirrored into the settings row by this plugin. */
export interface BackgroundSettingsState {
    enabled: boolean;
    intensity: number;
}
type BackgroundSettingsActions = {
    sync: (draft: BackgroundSettingsState, enabled: boolean, intensity: number) => void;
};
/** Declare the settings row's only write path. */
export declare function createBackgroundSettingsStore(): EngineStoreHandle<BackgroundSettingsState, BackgroundSettingsActions>;
export {};
//# sourceMappingURL=settings-store.d.ts.map