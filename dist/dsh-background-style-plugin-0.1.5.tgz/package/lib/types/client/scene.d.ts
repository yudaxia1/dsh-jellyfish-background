/** Owns one fixed canvas, its animation frame, and all environment listeners. */
export declare class AbyssScene {
    private readonly canvas;
    private readonly context;
    private readonly motion;
    private readonly started;
    private frame;
    private lastPaint;
    private width;
    private height;
    private intensity;
    private readonly onResize;
    private readonly onVisibility;
    private readonly onMotion;
    private readonly tick;
    /** Mount the background canvas and start only when motion is allowed. */
    constructor(intensity: number);
    /** Change motion and glow strength without rebuilding the canvas. */
    setIntensity(intensity: number): void;
    /** Remove every resource owned by this plugin instance. */
    dispose(): void;
    private resize;
    private resume;
    private paint;
    private drawStars;
    private drawJellyfish;
}
//# sourceMappingURL=scene.d.ts.map