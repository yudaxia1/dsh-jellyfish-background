# DSH Deep-Sea ASCII Jellyfish Background

An animated full-window theme plugin for DSH `0.2.1-rc.3`. It draws character-cell jellyfish, a faint grid, and drifting stars behind the Web interface while applying a dark translucent palette. Native DSH controls and interactions remain in place.

The background starts enabled on first install. Open **Settings → General → Deep-sea ASCII jellyfish** to disable it or adjust motion intensity. Disabling restores the last selected DSH appearance. Appearance changes made while the plugin is enabled take effect after disabling it.

The animation pauses when the page is hidden. Reduced-motion mode and intensity 0 render a static scene. Preferences use browser `localStorage` and synchronize across tabs on the same origin.

## Install

Install the included `dsh-background-style-plugin-0.1.4.tgz` into a compatible Web profile:

```sh
dsh plugin --profile web add /path/to/dsh-background-style-plugin-0.1.4.tgz
```

For installed Desktop, launch it once, quit fully, then use its bundled `dsh` command with `--profile desktop` and reopen the app.

## Build from source

Copy this directory to `packages/client/dsh-background-style-plugin` inside the DSH `0.2.1-rc.3` source tree. From the DSH root, install dependencies and run in order:

```sh
node --max-old-space-size=4096 ./node_modules/typescript/bin/tsc -b tsconfig.host.json
pnpm exec tsdown --config-loader native --env.DSH_BUILD_FACE host
pnpm exec tsc -b packages/client/dsh-background-style-plugin/tsconfig.json
pnpm exec tsdown --config-loader native --config packages/client/dsh-background-style-plugin/tsdown.config.ts --env.DSH_BUILD_FACE client
cd packages/client/dsh-background-style-plugin
pnpm pack
```

The Host entry and browser bundle are declared in `package.json`; the bundle patch installs the plugin into a profile. The browser half uses the official theme and Settings slot services, and does not patch DSH source files.

Compatibility is limited to the exact tested DSH release in `engines.dsh`. Recheck the client APIs, CSS tokens, and window layers before expanding the supported version range.

## Preview

Open `preview.html` to see the standalone animation. `preview.png` is a 1440 × 900 screenshot. The sidebar, text, and composer in the preview are illustrative; the installed plugin keeps DSH's own interface.
